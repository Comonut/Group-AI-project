package VirtualPiano;

import java.io.IOException;

import javax.sound.midi.InvalidMidiDataException;

public class MidiExporterInitialiser {
	public static void main(String[] args) throws InvalidMidiDataException, IOException {
		MidiExporter ex = new MidiExporter("1,0,3,1.0;2,0,3,1.0;3,0,3,0.5;4,0,3,0.5;5,0,3,2.0;");
		ex.writeNotes();
		ex.createFile();
	}
}
