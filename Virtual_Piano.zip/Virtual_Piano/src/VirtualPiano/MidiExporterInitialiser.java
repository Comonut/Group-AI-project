package VirtualPiano;

public class MidiExporterInitialiser {
	public static void main(String[] args) {
	MidiExporter ex = new MidiExporter("1,0,3,1.0;2,0,3,1.0;3,0,3,0.5;4,0,3,0.5;5,0,3,2.0");
 }
}
