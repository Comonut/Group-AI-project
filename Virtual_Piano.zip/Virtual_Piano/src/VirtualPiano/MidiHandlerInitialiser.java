package VirtualPiano;
import java.awt.EventQueue;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

public class MidiHandlerInitialiser {
	

public static void main(String[] args) throws SQLException, IOException {
	DBController db = new DBController("storage");
	
	EventQueue.invokeLater(new Runnable() {
		public void run() {
			try {
				VirtualPiano frame = new VirtualPiano();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	});
	//db.initDB(); //THIS WILL ERASE THE DATABASE
	MidiHandler midiIn = new MidiHandler(db);
	
}

}
