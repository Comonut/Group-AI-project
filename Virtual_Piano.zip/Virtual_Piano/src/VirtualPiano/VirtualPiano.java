package VirtualPiano;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

import sun.audio.*;
import java.io.*;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;



public class VirtualPiano extends JFrame implements ActionListener {

	
	private JPanel contentPane;
	private JTextField txtUserUsername;
	private JTextField txtNotePlayed;
	private JTextField txtNumberOfNotes;
	private JPanel panel_4;
	private JTextField txtSettings;
	private JTextField txtSave;
	private JTextField txtStart;
	private JTextField txtFinish;
	private JTextField txtPlay;
	public static JTextField Display;
	public static JButton btnStart;
	public static JButton btnFinish;
	private JTextField txtSpeedOfReplay;
	private JTextField ReplaySpeedField;
	private JTextField txtInsertANumber;
	private JTextField txtSettings_1;
	private JTextField txtNumberOfNotes_1;
	private JTextField generatedNotesField;
	private JTextField textField_1;
	protected JPanel mainPanel;



	public VirtualPiano() {
		String keyName;
		setResizable(false);
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1171, 468);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		mainPanel = new JPanel();
		mainPanel.setForeground(Color.WHITE);
		mainPanel.setBackground(Color.BLACK);
		contentPane.add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(459, 33, 257, 66);
		panel_3.setLayout(null);
				
				JButton btnHelp = new JButton("Help");
				btnHelp.setBackground(Color.WHITE);
				btnHelp.setBounds(6, 6, 57, 15);
				mainPanel.add(btnHelp);
				
				
				JPanel helpPanel = new JPanel();
				helpPanel.setBounds(6, 33, 1157, 397);
				mainPanel.add(helpPanel);
				helpPanel.setLayout(null);
				helpPanel.setVisible(false);
				helpPanel.setEnabled(false);
				
				btnHelp.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						helpPanel.setVisible(true);
						helpPanel.setEnabled(true);
						for (Component c : mainPanel.getComponents()) c.setEnabled(false);
					}
				});
				
				JPanel SettingsPanel = new JPanel();
				SettingsPanel.setBounds(6, 33, 1157, 397);
				mainPanel.add(SettingsPanel);
				SettingsPanel.setLayout(null);
				
				txtSpeedOfReplay = new JTextField();
				txtSpeedOfReplay.setEditable(false);
				txtSpeedOfReplay.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
				txtSpeedOfReplay.setBackground(SystemColor.window);
				txtSpeedOfReplay.setText("       Speed of Replay: ");
				txtSpeedOfReplay.setBounds(39, 80, 208, 55);
				SettingsPanel.add(txtSpeedOfReplay);
				txtSpeedOfReplay.setColumns(10);
				
				ReplaySpeedField = new JTextField();
				ReplaySpeedField.setBounds(377, 96, 80, 26);
				SettingsPanel.add(ReplaySpeedField);
				ReplaySpeedField.setColumns(10);
				
				txtInsertANumber = new JTextField();
				txtInsertANumber.setEditable(false);
				txtInsertANumber.setBackground(SystemColor.window);
				txtInsertANumber.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
				txtInsertANumber.setText("Insert a number from ");
				txtInsertANumber.setBounds(476, 96, 251, 26);
				SettingsPanel.add(txtInsertANumber);
				txtInsertANumber.setColumns(10);
				
				JButton btnBackSettings = new JButton("Back");
				btnBackSettings.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						SettingsPanel.setVisible(false);
						SettingsPanel.setEnabled(false);
						for (Component c : mainPanel.getComponents()) c.setEnabled(true);
					}
				});
				btnBackSettings.setBounds(6, 6, 117, 29);
				SettingsPanel.add(btnBackSettings);
				
				txtSettings_1 = new JTextField();
				txtSettings_1.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
				txtSettings_1.setBackground(SystemColor.window);
				txtSettings_1.setText("  Settings Menu");
				txtSettings_1.setBounds(489, 0, 164, 32);
				SettingsPanel.add(txtSettings_1);
				txtSettings_1.setColumns(10);
				SettingsPanel.setVisible(false);
				SettingsPanel.setEnabled(false);
				
				txtNumberOfNotes_1 = new JTextField();
				txtNumberOfNotes_1.setText("       Number of notes generated: ");
				txtNumberOfNotes_1.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
				txtNumberOfNotes_1.setEditable(false);
				txtNumberOfNotes_1.setColumns(10);
				txtNumberOfNotes_1.setBackground(SystemColor.window);
				txtNumberOfNotes_1.setBounds(38, 147, 296, 55);
				SettingsPanel.add(txtNumberOfNotes_1);
				
				generatedNotesField = new JTextField();
				generatedNotesField.setColumns(10);
				generatedNotesField.setBounds(377, 163, 80, 26);
				SettingsPanel.add(generatedNotesField);
				
				textField_1 = new JTextField();
				textField_1.setText("Insert a number from ");
				textField_1.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
				textField_1.setEditable(false);
				textField_1.setColumns(10);
				textField_1.setBackground(SystemColor.window);
				textField_1.setBounds(476, 163, 251, 26);
				SettingsPanel.add(textField_1);
				
				Display = new JTextField();
				Display.setEditable(false);
				Display.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
				Display.setBounds(446, 46, 258, 44);
				mainPanel.add(Display);
				Display.setColumns(10);
				helpPanel.setVisible(false);
				helpPanel.setEnabled(false);
				
		
		txtUserUsername = new JTextField();
		txtUserUsername.setEditable(false);
		txtUserUsername.setForeground(Color.WHITE);
		txtUserUsername.setBackground(Color.DARK_GRAY);
		txtUserUsername.setText("User: Username");
		txtUserUsername.setBounds(1025, 6, 130, 15);
		mainPanel.add(txtUserUsername);
		txtUserUsername.setColumns(10);
		
		txtNotePlayed = new JTextField();
		txtNotePlayed.setBounds(63, 5, 130, 26);
		txtNotePlayed.setText("Note Played");
		panel_3.add(txtNotePlayed);
		txtNotePlayed.setColumns(10);
		
		txtNumberOfNotes = new JTextField();
		txtNumberOfNotes.setText("Number of notes played");
		txtNumberOfNotes.setBounds(51, 34, 174, 26);
		panel_3.add(txtNumberOfNotes);
		txtNumberOfNotes.setColumns(10);
		
		panel_4 = new JPanel();
		panel_4.setEnabled(false);
		panel_4.setBackground(SystemColor.inactiveCaption);
		panel_4.setBounds(486, 6, 182, 15);
		mainPanel.add(panel_4);
		
		JButton Do_Sharp_ = new JButton();
		Do_Sharp_.addActionListener(this);
		Do_Sharp_.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Do_Sharp_.setName("Do_Sharp_");
		Do_Sharp_.setBounds(808, 111, 45, 193);
		mainPanel.add(Do_Sharp_);
		
		JButton Sol_Sharp_ = new JButton();
		Sol_Sharp_.addActionListener(this);
		Sol_Sharp_.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Sol_Sharp_.setName("Sol_Sharp_");
		Sol_Sharp_.setBounds(1034, 111, 45, 193);
		mainPanel.add(Sol_Sharp_);
		
		JButton La_Sharp_ = new JButton();
		La_Sharp_.addActionListener(this);
		La_Sharp_.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		La_Sharp_.setName("La_Sharp_");
		La_Sharp_.setBounds(1091, 111, 45, 193);
		mainPanel.add(La_Sharp_);
		
		JButton Fa_Sharp_ = new JButton();
		Fa_Sharp_.addActionListener(this);
		Fa_Sharp_.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Fa_Sharp_.setName("Fa_Sharp_");
		Fa_Sharp_.setBounds(977, 111, 45, 193);
		mainPanel.add(Fa_Sharp_);
		
		JButton Re_Sharp_ = new JButton();
		Re_Sharp_.addActionListener(this);
		Re_Sharp_.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Re_Sharp_.setName("Re_Sharp_");
		Re_Sharp_.setBounds(865, 111, 45, 193);
		mainPanel.add(Re_Sharp_);
		
		JButton _Re_Sharp = new JButton();
		_Re_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		_Re_Sharp.setBounds(96, 111, 45, 193);
		mainPanel.add(_Re_Sharp);
		_Re_Sharp.addActionListener(this);
		_Re_Sharp.setName("_Re_Sharp");
		
		JButton _Do_Sharp = new JButton();
		_Do_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		_Do_Sharp.setBounds(39, 111, 45, 193);
		mainPanel.add(_Do_Sharp);
		_Do_Sharp.addActionListener(this);
		_Do_Sharp.setName("_Do_Sharp");
		
		JButton _Sol_Sharp = new JButton();
		_Sol_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		_Sol_Sharp.setBounds(262, 111, 45, 193);
		mainPanel.add(_Sol_Sharp);
		_Sol_Sharp.addActionListener(this);
		_Sol_Sharp.setName("_Sol_Sharp");
		
		JButton _Fa_Sharp = new JButton();
		_Fa_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		_Fa_Sharp.setBounds(205, 111, 45, 193);
		mainPanel.add(_Fa_Sharp);
		_Fa_Sharp.addActionListener(this);
		_Fa_Sharp.setName("_Fa_Sharp");
		
		JButton _La_Sharp = new JButton();
		_La_Sharp.addActionListener(this);
		_La_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		_La_Sharp.setBounds(319, 111, 45, 193);
		mainPanel.add(_La_Sharp);
		_La_Sharp.setName("_La_Sharp");
		
		JButton Do_Sharp = new JButton();
		Do_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Do_Sharp.setBounds(423, 111, 45, 193);
		mainPanel.add(Do_Sharp);
		Do_Sharp.addActionListener(this);
		Do_Sharp.setName("Do_Sharp");
		
		JButton La_Sharp = new JButton();
		La_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		La_Sharp.setBounds(706, 111, 45, 193);
		mainPanel.add(La_Sharp);
		La_Sharp.addActionListener(this);
		La_Sharp.setName("La_Sharp");
		
		JButton Sol_Sharp = new JButton();
		Sol_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Sol_Sharp.setBounds(649, 111, 45, 193);
		mainPanel.add(Sol_Sharp);
		Sol_Sharp.addActionListener(this);
		Sol_Sharp.setName("Sol_Sharp");
		
		JButton Fa_Sharp = new JButton();
		Fa_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Fa_Sharp.setBounds(592, 111, 45, 193);
		mainPanel.add(Fa_Sharp);
		Fa_Sharp.addActionListener(this);
		Fa_Sharp.setName("Fa_Sharp");
		
		JButton Re_Sharp = new JButton();
		Re_Sharp.setIcon(new ImageIcon("/Users/gabriela/Desktop/Ai Project/Virtual_Piano/Black_Gradient.jpg"));
		Re_Sharp.setBounds(480, 111, 45, 193);
		mainPanel.add(Re_Sharp);
		Re_Sharp.addActionListener(this);
		Re_Sharp.setName("Re_Sharp");
		
		JButton Do = new JButton();
		Do.setForeground(Color.WHITE);
		Do.setBounds(391, 111, 57, 319);
		mainPanel.add(Do);
		Do.addActionListener(this);
		Do.setName("Do");
		
		JButton Re = new JButton();
		Re.setForeground(Color.WHITE);
		Re.setBounds(446, 111, 57, 319);
		mainPanel.add(Re);
		Re.addActionListener(this);
		Re.setName("Re");
		
		JButton Mi = new JButton();
		Mi.setForeground(Color.WHITE);
		Mi.setBounds(501, 111, 57, 319);
		mainPanel.add(Mi);
		Mi.addActionListener(this);
		Mi.setName("Mi");
		
		JButton Fa = new JButton();
		Fa.setForeground(Color.WHITE);
		Fa.setBounds(556, 111, 57, 319);
		mainPanel.add(Fa);
		Fa.addActionListener(this);
		Fa.setName("Fa");
		
		JButton Sol = new JButton();
		Sol.setForeground(Color.WHITE);
		Sol.setBounds(611, 111, 57, 319);
		mainPanel.add(Sol);
		Sol.addActionListener(this);
		Sol.setName("Sol");
		
		JButton La = new JButton();
		La.setForeground(Color.WHITE);
		La.setBounds(666, 111, 57, 319);
		mainPanel.add(La);
		La.addActionListener(this);
		La.setName("La");
		
		JButton Si = new JButton();
		Si.setForeground(Color.WHITE);
		Si.setBounds(721, 111, 57, 319);
		mainPanel.add(Si);
		Si.addActionListener(this);
		Si.setName("Si");
		
		JButton _Do = new JButton();
		_Do.setForeground(Color.WHITE);
		_Do.setBounds(6, 111, 57, 319);
		mainPanel.add(_Do);
		_Do.addActionListener(this);
		_Do.setName("_Do");
		
		JButton _Re = new JButton();
		_Re.setForeground(Color.WHITE);
		_Re.setBounds(61, 111, 57, 319);
		mainPanel.add(_Re);
		_Re.addActionListener(this);
		_Re.setName("_Re");
		
		JButton _Mi = new JButton();
		_Mi.setForeground(Color.WHITE);
		_Mi.setBounds(116, 111, 57, 319);
		mainPanel.add(_Mi);
		_Mi.addActionListener(this);
		_Mi.setName("_Mi");
		
		JButton _Fa = new JButton();
		_Fa.setForeground(Color.WHITE);
		_Fa.setBounds(171, 111, 57, 319);
		mainPanel.add(_Fa);
		_Fa.addActionListener(this);
		_Fa.setName("_Fa");
		
		JButton _Sol = new JButton();
		_Sol.setForeground(Color.WHITE);
		_Sol.setBounds(226, 111, 57, 319);
		mainPanel.add(_Sol);
		_Sol.addActionListener(this);
		_Sol.setName("_Sol");
		
		JButton _La = new JButton();
		_La.setForeground(Color.WHITE);
		_La.setBounds(281, 111, 57, 319);
		mainPanel.add(_La);
		_La.addActionListener(this);
		_La.setName("_La");
		
		JButton _Si = new JButton();
		_Si.setForeground(Color.WHITE);
		_Si.setBounds(336, 111, 57, 319);
		mainPanel.add(_Si);
		_Si.addActionListener(this);
		_Si.setName("_Si");
		
		JButton Do_ = new JButton();
		Do_.addActionListener(this);
		Do_.setName("Do_");
		Do_.setForeground(Color.WHITE);
		Do_.setBounds(776, 111, 57, 319);
		mainPanel.add(Do_);
		
		JButton Re_ = new JButton();
		Re_.addActionListener(this);
		Re_.setName("Re_");
		Re_.setForeground(Color.WHITE);
		Re_.setBounds(831, 111, 57, 319);
		mainPanel.add(Re_);
		
		JButton Mi_ = new JButton();
		Mi_.addActionListener(this);
		Mi_.setName("Mi_");
		Mi_.setForeground(Color.WHITE);
		Mi_.setBounds(886, 111, 57, 319);
		mainPanel.add(Mi_);
		
		JButton Fa_ = new JButton();
		Fa_.addActionListener(this);
		Fa_.setName("Fa_");
		Fa_.setForeground(Color.WHITE);
		Fa_.setBounds(941, 111, 57, 319);
		mainPanel.add(Fa_);
		
		JButton Sol_ = new JButton();
		Sol_.addActionListener(this);
		Sol_.setName("Sol_");
		Sol_.setForeground(Color.WHITE);
		Sol_.setBounds(996, 111, 57, 319);
		mainPanel.add(Sol_);
		
		JButton La_ = new JButton();
		La_.addActionListener(this);
		La_.setName("La_");
		La_.setForeground(Color.WHITE);
		La_.setBounds(1051, 111, 57, 319);
		mainPanel.add(La_);
		
		JButton Si_ = new JButton();
		Si_.addActionListener(this);
		Si_.setName("Si_");
		Si_.setForeground(Color.WHITE);
		Si_.setBounds(1106, 111, 57, 319);
		mainPanel.add(Si_);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.DARK_GRAY);
		panel_1.setBounds(6, 6, 1149, 15);
		mainPanel.add(panel_1);
		
		btnFinish = new JButton("");
		btnFinish.setForeground(UIManager.getColor("Button.disabledText"));
		btnFinish.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		btnFinish.setBounds(865, 59, 131, 29);
		mainPanel.add(btnFinish);
		
		JButton btnPlay = new JButton("");
		btnPlay.setForeground(UIManager.getColor("Button.disabledText"));
		btnPlay.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		btnPlay.setBounds(1005, 59, 131, 29);
		mainPanel.add(btnPlay);
		
		//Settings button to show panel
		JButton btnSettings = new JButton("");
		btnSettings.setForeground(UIManager.getColor("Button.disabledText"));
		btnSettings.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		btnSettings.setBounds(97, 59, 131, 29);
		mainPanel.add(btnSettings);	
		btnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SettingsPanel.setVisible(true);
				SettingsPanel.setEnabled(true);
				for (Component c : mainPanel.getComponents()) c.setEnabled(false);
			}
		});
		
		JButton btnSaveTrack = new JButton("");
		btnSaveTrack.setForeground(Color.GRAY);
		btnSaveTrack.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		btnSaveTrack.setBounds(300, 59, 131, 29);
		mainPanel.add(btnSaveTrack);
		
		btnStart = new JButton("");
		btnStart.setForeground(Color.GRAY);
		btnStart.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		btnStart.setBounds(721, 59, 131, 29);
		mainPanel.add(btnStart);
		
		txtSettings = new JTextField();
		txtSettings.setEditable(false);
		txtSettings.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		txtSettings.setForeground(Color.WHITE);
		txtSettings.setBackground(Color.BLACK);
		txtSettings.setText("  Settings");
		txtSettings.setBounds(121, 33, 78, 26);
		mainPanel.add(txtSettings);
		txtSettings.setColumns(10);
		
		txtSave = new JTextField();
		txtSave.setEditable(false);
		txtSave.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		txtSave.setText("    Save");
		txtSave.setForeground(Color.WHITE);
		txtSave.setColumns(10);
		txtSave.setBackground(Color.BLACK);
		txtSave.setBounds(328, 33, 78, 26);
		mainPanel.add(txtSave);
		
		txtStart = new JTextField();
		txtStart.setEditable(false);
		txtStart.setText("    Start");
		txtStart.setForeground(Color.WHITE);
		txtStart.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		txtStart.setColumns(10);
		txtStart.setBackground(Color.BLACK);
		txtStart.setBounds(746, 33, 78, 26);
		mainPanel.add(txtStart);
		
		txtFinish = new JTextField();
		txtFinish.setEditable(false);
		txtFinish.setText("    Finish");
		txtFinish.setForeground(Color.WHITE);
		txtFinish.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		txtFinish.setColumns(10);
		txtFinish.setBackground(Color.BLACK);
		txtFinish.setBounds(891, 33, 78, 26);
		mainPanel.add(txtFinish);
		
		txtPlay = new JTextField();
		txtPlay.setEditable(false);
		txtPlay.setText("    Play");
		txtPlay.setForeground(Color.WHITE);
		txtPlay.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		txtPlay.setColumns(10);
		txtPlay.setBackground(Color.BLACK);
		txtPlay.setBounds(1035, 33, 78, 26);
		mainPanel.add(txtPlay);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
			Object key = ((Component) e.getSource()).getName();
			
			String audio = key + ".wav";    
			AudioInputStream audioInputStream;
			try {
				audioInputStream = AudioSystem.getAudioInputStream(new File(audio).getAbsoluteFile());
			Clip clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			clip.start();
			} catch (UnsupportedAudioFileException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (LineUnavailableException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	}
}
